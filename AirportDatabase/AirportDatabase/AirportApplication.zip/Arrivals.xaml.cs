﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirportDatabase
{
    /// <summary>
    /// Логика взаимодействия для Arrivals.xaml
    /// </summary>
    public partial class Arrivals : Window
    {
        public Arrivals()
        {
            InitializeComponent();
        }

        private void Arrivals_List_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
